// index.js
const app = getApp();
import mqtt from '../../utils/mqtt.js';
const aliyunOpt = require('../../utils/aliyun/aliyun_connect.js');

Page({
  data: {
    qwe: null
  },
  onLoad: function () {
    let that = this;
    let mqttClient = app.globalData.mqttClient;

    if (!mqttClient) {
      console.error("全局 MQTT 连接对象不存在！");
      return;
    }

    // 页面初始化逻辑...
    mqttClient.on('connect', function (connack) {
      console.log("连接成功");

      // 订阅主题
      mqttClient.subscribe('/a1fB1NdOEHt/asdasdasd/user/topic', function (err) {
        if (err) {
          console.error("订阅失败:", err);
        } else {
          console.log("订阅成功");
        }
      });
    });

    // 监听接收消息
    mqttClient.on("message", function (topic, payload) {
      console.log("收到消息，主题:", topic, " 数据:", payload.toString());
      
      try {
        // 解析 JSON 数据
        let jsonData = JSON.parse(payload.toString());
        
        // 获取 qwe 字段的值
        let qweValue = jsonData.qwe;

        // 更新页面上的数据
        that.setData({
          qwe: qweValue
        });
      } catch (error) {
        console.error("解析 JSON 失败:", error);
      }

      // 在这里处理接收到的数据，例如更新页面上的数据
    });

    // 页面其他初始化逻辑...
  },
  qwe(){
    wx.navigateTo({
      url: '/pages/ceshi/ceshi',
    })
  },
  onUnload: function () {
    // 页面销毁时断开连接
    let mqttClient = app.globalData.mqttClient;
    if (mqttClient && mqttClient.connected) {
      console.log("Closing MQTT connection...");
      mqttClient.end();
      console.log("MQTT connection closed.");
    }
  },

  onClickOpen() {
    // 发送开启命令逻辑...
    // 添加你的按钮点击逻辑
    console.log("点击了开启按钮");
    // 例如：发送开启命令
    // this.sendCommond('set', 1);

    // 发送消息 {"qwe":123}
    this.sendCommond('set', '{"qwe":123}');
  },

  onClickOff() {
    // 发送关闭命令逻辑...
    // 添加你的按钮点击逻辑
    console.log("点击了关闭按钮");
    // 例如：发送关闭命令
    // this.sendCommond('set', 0);
  },

  sendCommond(cmd, data) {
    let sendData = {
      cmd: cmd,
      data: data,
    };

    let mqttClient = app.globalData.mqttClient;

    // 发布消息
    mqttClient.publish('/a1fB1NdOEHt/asdasdasd/user/topic', JSON.stringify(sendData), function (err) {
      if (err) {
        console.error("发布消息失败:", err);
      } else {
        console.log("发布消息成功");
      }
    });
  }
});
