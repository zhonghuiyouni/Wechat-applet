// app.js
App({
  globalData: {
    mqttClient: null,
  },
  onLaunch: function () {
    let mqtt = require('./utils/mqtt.js');
    let aliyunOpt = require('./utils/aliyun/aliyun_connect.js');

    let clientOpt = aliyunOpt.getAliyunIotMqttClient({
      productKey: 'a1fB1NdOEHt',
      deviceName: 'asdasdasd',
      deviceSecret: 'af15d4121b4c069c2215580b2672ee6e',
      regionId: 'cn-shanghai',
    });

    let host = 'wxs://' + clientOpt.host;

    this.globalData.mqttClient = mqtt.connect(host, {
      clientId: clientOpt.clientId,
      password: clientOpt.password,
      username: clientOpt.username,
    });

    this.globalData.mqttClient.on('connect', function (connack) {
      console.log("全局 MQTT 连接成功");
    });

    // 其他事件监听等操作...
  },
});
